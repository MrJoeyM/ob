#!/bin/bash

source /opt/ros/indigo/setup.bash
source /home/exbot/catkin_ws/devel/setup.bash

roslaunch dji_sdk sdk_manifold.launch
